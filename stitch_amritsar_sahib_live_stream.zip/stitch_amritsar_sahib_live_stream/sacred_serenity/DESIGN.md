---
name: Sacred Serenity
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#44474e'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#75777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4c5f80'
  primary: '#000b21'
  on-primary: '#ffffff'
  primary-container: '#0d2240'
  on-primary-container: '#778aad'
  inverse-primary: '#b4c7ed'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#0f0c02'
  on-tertiary: '#ffffff'
  tertiary-container: '#262212'
  on-tertiary-container: '#918973'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b4c7ed'
  on-primary-fixed: '#051b39'
  on-primary-fixed-variant: '#344767'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ece2c9'
  tertiary-fixed-dim: '#cfc6ae'
  on-tertiary-fixed: '#201b0c'
  on-tertiary-fixed-variant: '#4c4634'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Libre Caslon Text
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  video-time:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin-desktop: 80px
  container-margin-mobile: 20px
  gutter: 24px
  video-aspect-ratio: 16/9
---

## Brand & Style
The brand personality is spiritual, serene, and deeply respectful, designed to provide a digital sanctuary for users connecting with Sri Amritsar Sahib. The target audience includes the global Sikh diaspora and spiritual seekers who value both tradition and professional-grade technology. 

The design style is a blend of **Minimalism** and **Modern Corporate**, focusing on high-quality content immersion. It avoids visual clutter to foster a sense of peace. Subtle spiritual motifs, such as geometry inspired by Sikh architecture, are used sparingly as background textures. The emotional response should be one of reverence, calm, and unwavering reliability.

## Colors
The palette is rooted in the majesty of the Golden Temple and the twilight skies over the Sarovar.
- **Primary (Midnight Blue):** Used for headers, deep backgrounds, and primary navigation to evoke the infinite sky.
- **Secondary (Temple Gold):** Reserved for moments of spiritual significance, active states, and call-to-action elements. It represents the brilliance of the Darbar Sahib.
- **Tertiary (Cream/Parchment):** Used for subtle card backgrounds and dividers, softening the interface compared to pure white.
- **Neutral:** A range of clean whites and soft grays to ensure the video content remains the focal point.
- **Status Colors:** A specific 'Live' red is used for real-time broadcasts from the Harmandir Sahib.

## Typography
This design system employs a sophisticated typographic pairing to balance heritage with modern utility. 
- **Libre Caslon Text** is used for headings and titles, providing a literary, authoritative, and timeless feel that honors sacred texts.
- **Plus Jakarta Sans** handles all functional UI, body text, and labels. Its soft, rounded terminals maintain the "welcoming" brand pillar while ensuring maximum legibility on small screens during long reading or viewing sessions.
- **Hierarchical Note:** Use "Label-Caps" for categories like "Hukamnama" or "Live Now" to provide clear structural markers without overwhelming the serif headlines.

## Layout & Spacing
The layout follows a **Fixed Grid** model on desktop to maintain a centered, cinematic feel, and a **Fluid Grid** on mobile to maximize screen real estate for video.

- **Desktop:** 12-column grid with a max-width of 1280px. Large margins (80px) create a "gallery" effect.
- **Mobile:** Single column with 20px side margins.
- **Spacing Logic:** Based on an 8px base unit. Use generous padding (32px+) between content sections to maintain the "serene" aesthetic. Video thumbnails should always maintain a 16:9 aspect ratio to ensure consistency in the feed.

## Elevation & Depth
Depth is expressed through **Tonal Layers** and **Ambient Shadows** to mimic the soft lighting of the temple complex at dawn.
- **Surface 0:** The main canvas, using the Neutral or Tertiary color.
- **Surface 1 (Cards):** Slightly elevated with an extremely soft, large-radius shadow (Blur: 20px, Opacity: 4%, Color: Primary).
- **Video Player Overlay:** Uses a subtle gradient wash (Primary at 60% opacity to transparent) to ensure player controls are visible over bright video content.
- **Modals:** Use a Backdrop Blur (12px) to keep the user grounded in their previous context while focusing on the new task.

## Shapes
The shape language is **Rounded**, reflecting the organic curves of the Sarovar and the arches of the Darbar Sahib. 
- **Buttons and Inputs:** 0.5rem (8px) corner radius.
- **Video Thumbnails:** 1rem (16px) corner radius to give a premium, modern app feel.
- **Selection Indicators:** Use pill-shapes (full rounding) for chips and active calendar dates to distinguish them from structural containers.

## Components
- **Video Player:** Controls should be minimal. Use "Temple Gold" for the progress bar and "Midnight Blue" for the control bar background. Include a 'Theater Mode' that transitions the UI to a full dark theme.
- **Audio Controls:** For Nitnem or Kirtan audio, use a sticky bottom player with a waveform visualization in Secondary color.
- **Religious Calendar Events:** Use a grid-based card system. Current Gurpurb or historical dates should be highlighted with a gold border-top (2px) and a subtle parchment background.
- **Live Badge:** A small pill-shaped component with a pulsing animation to indicate real-time feeds from Amritsar.
- **Primary Buttons:** Solid Midnight Blue with White text. For spiritual CTAs (e.g., "Donate to Langar"), use a Temple Gold background with Midnight Blue text.
- **Input Fields:** Minimalist style with a bottom-only border that thickens and changes to Gold on focus.